<?php
header('Content-Type: application/json');
//koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo "Gagal koneksi ke database: " . mysqli_connect_errno();
}

//tangkap data yang dikirim dari form
$namaLengkap = $_POST['nama_lengkap'];
$telp = $_POST['telp'];
$id_kartu = $_POST['id_kartu'];
$tipe_user = $_POST['tipe_user'];
$username = $_POST['username'];
$password = $_POST['password'];

//proses
$queryRegister = "SELECT * FROM pembeli WHERE username = '$username'";

//eksekusi
$obj_query = mysqli_query($koneksi, $queryRegister);
$data = mysqli_fetch_array($obj_query);

//periksa
if (!empty($username) && !empty($password) && !empty($namaLengkap)) {
    if ($data == 0) {
        $query_update = "ALTER TABLE pembeli AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE pembeli SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);

        $regis = "INSERT INTO pembeli (nama_lengkap, telp, username, password) VALUES ('$namaLengkap', '$telp', '$username', '$password')";

        $token = uniqid();

        mysqli_query($koneksi, $regis);
        $id_user = mysqli_insert_id($koneksi);

        $query_update_saldo = "ALTER TABLE saldo AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update_saldo);
        $query_update_saldo = "SET @count = 0";
        mysqli_query($koneksi, $query_update_saldo);
        $query_update_saldo = "UPDATE saldo SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update_saldo);

        $insert_saldo = "INSERT INTO saldo (id_user, tipe_user, nama_pemilik, id_kartu) VALUES ('$id_user', '$tipe_user', '$namaLengkap', '$id_kartu')";

        mysqli_query($koneksi, $insert_saldo);

        echo json_encode(
            array(
                'message' => 'Berhasil register!',
                'token' => $token,
            )
        );
    } else {
        echo json_encode(
            array(
                'message' => 'Email sudah terdaftar!',
                'token' => null,
            )
        );
    }
} else {
    echo json_encode(
        array(
            'message' => 'Data tidak boleh kosong!',
        )
    );
}
