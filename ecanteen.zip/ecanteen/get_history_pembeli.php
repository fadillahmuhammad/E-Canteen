<?php
header('Content-Type: application/json');

// koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Gagal koneksi ke database: " . mysqli_connect_error()]);
    exit();
}

$query_update = "ALTER TABLE history AUTO_INCREMENT=1";
mysqli_query($koneksi, $query_update);
$query_update = "SET @count = 0";
mysqli_query($koneksi, $query_update);
$query_update = "UPDATE history SET id = @count:= @count + 1";
mysqli_query($koneksi, $query_update);

if (isset($_POST['id_pembeli']) && isset($_POST['year']) && isset($_POST['month'])) {
    $id = $_POST['id_pembeli'];
    $year = $_POST['year'];
    $month = $_POST['month'];

    $query_history = "SELECT 
                    his.id,
                    his.no_pesanan, 
                    his.id_menu,
                    his.id_pembeli, 
                    his.qty, 
                    his.catatan, 
                    his.jam_pesan,
                    his.jml_harga,
                    his.tanggal,
                    m.id_penjual,
                    m.nama,
                    m.deskripsi,
                    m.harga,
                    m.stok,
                    m.gambar,
                    pen.nama_toko,
                    pen.nama_lengkap,
                    pen.telp
                FROM history his
                LEFT JOIN menu m ON his.id_menu = m.id 
                LEFT JOIN penjual pen ON m.id_penjual = pen.id 
                WHERE his.id_pembeli = $id
                AND YEAR(his.tanggal) = $year
                AND MONTH(his.tanggal) = $month";

    $result = mysqli_query($koneksi, $query_history);

    if ($result) {
        $data = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }

        // Query untuk mendapatkan jumlah pesanan
        $query_count = "SELECT COUNT(*) as jumlah_pesanan FROM history WHERE id_pembeli = $id AND YEAR(tanggal) = $year AND MONTH(tanggal) = $month";
        $result_count = mysqli_query($koneksi, $query_count);
        $jumlah_pesanan = mysqli_fetch_assoc($result_count)['jumlah_pesanan'];

        // Query untuk mendapatkan total harga
        $query_total = "SELECT SUM(jml_harga) as total_harga FROM history WHERE id_pembeli = $id AND YEAR(tanggal) = $year AND MONTH(tanggal) = $month";
        $result_total = mysqli_query($koneksi, $query_total);
        $total_harga = mysqli_fetch_assoc($result_total)['total_harga'];

        echo json_encode(array(
            "status" => "success",
            "data_history_pembeli" => $data,
            "jumlah_pesanan" => $jumlah_pesanan,
            "total_harga" => $total_harga
        ));
    } else {
        echo json_encode(array("status" => "error", "message" => "Query gagal: " . mysqli_error($koneksi)));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Parameter tidak lengkap"));
}

mysqli_close($koneksi);
