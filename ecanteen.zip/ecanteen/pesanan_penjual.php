<?php
header('Content-Type: application/json');

// Koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(array("status" => "error", "message" => "Gagal koneksi ke database: " . mysqli_connect_error()));
    exit();
}

if (isset($_POST['id_penjual'])) {
    $id = $_POST['id_penjual'];

    $query_new = "SELECT 
                    pes.id,
                    pes.no_pesanan, 
                    pes.id_menu,
                    pes.id_pembeli, 
                    pes.qty, 
                    pes.catatan, 
                    pes.jam_pesan, 
                    pes.jml_harga,
                    pes.tanggal,
                    pes.status,
                    m.id_penjual,
                    m.nama,
                    m.deskripsi,
                    m.harga,
                    m.stok,
                    m.gambar,
                    pem.nama_lengkap,
                    pem.telp
                FROM pesanan pes
                LEFT JOIN menu m ON pes.id_menu = m.id 
                LEFT JOIN pembeli pem ON pes.id_pembeli = pem.id
                WHERE m.id_penjual = $id";

    $result = mysqli_query($koneksi, $query_new);

    if ($result) {
        $data = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        echo json_encode(array("status" => "success", "data_pesanan_penjual" => $data));
    } else {
        echo json_encode(array("status" => "error", "message" => "Query gagal: " . mysqli_error($koneksi)));
    }
} else if (isset($_POST['id_pesanan_penjual'])) {
    $id = $_POST['id_pesanan_penjual'];

    $query_new = "SELECT 
                    pes.id,
                    pes.no_pesanan, 
                    pes.id_menu,
                    pes.id_pembeli, 
                    pes.qty, 
                    pes.catatan, 
                    pes.jam_pesan, 
                    pes.jml_harga,
                    pes.tanggal,
                    pes.status,
                    m.id_penjual,
                    m.nama,
                    m.deskripsi,
                    m.harga,
                    m.stok,
                    m.gambar,
                    pem.nama_lengkap,
                    pem.telp
                FROM pesanan pes
                LEFT JOIN menu m ON pes.id_menu = m.id 
                LEFT JOIN pembeli pem ON pes.id_pembeli = pem.id 
                WHERE pes.id = $id";

    $result = mysqli_query($koneksi, $query_new);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        echo json_encode(array("status" => "success", "data_detail_pesanan_penjual" => $row));
    } else {
        echo json_encode(array("status" => "error", "message" => "Query gagal: " . mysqli_error($koneksi)));
    }
} else if (isset($_POST['id']) && isset($_POST['status_bool'])) {
    $id = $_POST['id'];
    $status_bool = $_POST['status_bool'];

    $query_new = "UPDATE pesanan SET status = '$status_bool' WHERE id = '$id'";

    $result = mysqli_query($koneksi, $query_new);

    if ($result) {
        echo "Update berhasil.";
    } else {
        echo "Update gagal: " . mysqli_error($koneksi);
    }
}


mysqli_close($koneksi);
