<?php
header('Content-Type: application/json');

// koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Gagal koneksi ke database: " . mysqli_connect_error()]);
    exit();
}

$query_update = "ALTER TABLE pembeli AUTO_INCREMENT=1";
mysqli_query($koneksi, $query_update);
$query_update = "SET @count = 0";
mysqli_query($koneksi, $query_update);
$query_update = "UPDATE pembeli SET id = @count:= @count + 1";
mysqli_query($koneksi, $query_update);

if (isset($_POST['id'])){
    $id = $_POST['id'];

    $query = "SELECT * FROM pembeli WHERE id = '$id'";

    if (mysqli_query($koneksi, $query)) {
        $result = mysqli_query($koneksi, "SELECT * FROM pembeli WHERE id = $id");
        $profileData = mysqli_fetch_assoc($result);
        echo json_encode(["message" => "success", "profile" => $profileData]);
    } else {
        echo json_encode(["message" => "Error " . mysqli_error($koneksi)]);
    }
}

mysqli_close($koneksi);