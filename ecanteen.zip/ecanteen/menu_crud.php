<?php
header('Content-Type: application/json');

// koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Gagal koneksi ke database: " . mysqli_connect_error()]);
    exit();
}

// Perbarui urutan id_makanan di tabel makanan
$query_update = "ALTER TABLE menu AUTO_INCREMENT=1";
mysqli_query($koneksi, $query_update);
$query_update = "SET @count = 0";
mysqli_query($koneksi, $query_update);
$query_update = "UPDATE menu SET id = @count:= @count + 1";
mysqli_query($koneksi, $query_update);

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $result = mysqli_query($koneksi, "
                SELECT 
                    m.id,
                    p.nama_toko, 
                    p.nama_lengkap, 
                    p.deskripsi AS penjual_deskripsi, 
                    m.id_penjual, 
                    m.nama, 
                    m.deskripsi, 
                    m.harga, 
                    m.stok, 
                    m.gambar 
                FROM 
                    menu AS m 
                INNER JOIN 
                    penjual AS p 
                ON 
                    m.id_penjual = p.id
                ORDER BY 
                    RAND()
            ");
        $menus = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $menus[] = $row;
        }
        echo json_encode($menus);
        break;

    case 'POST':
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $result = mysqli_query($koneksi, "SELECT * FROM menu WHERE id_penjual = '$id'");
            $menus = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $menus[] = $row;
            }
            echo json_encode($menus);
        } elseif (isset($_POST['menu_id'])) {
            $id = $_POST['menu_id'];
            if ($id > 0) {
                $query = "SELECT * FROM menu WHERE id = '$id'";
                $result = mysqli_query($koneksi, $query);

                if ($result->num_rows > 0) {
                    // Ambil data dari hasil query
                    $data = $result->fetch_assoc();
                    echo json_encode([
                        'message' => 'success get data menu',
                        'menu' => $data
                    ]);
                } else {
                    echo json_encode([
                        'message' => 'No data found for the given id'
                    ]);
                }
            } else {
                echo json_encode([
                    'message' => 'Invalid id parameter'
                ]);
            }
        } elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
            // DELETE operation via POST method
            if (isset($_POST['id'])) {
                $id = $_POST['id'];

                // Hapus juga gambar terkait jika perlu
                $querySelectGambar = "SELECT gambar FROM menu WHERE id = $id";
                $resultSelectGambar = mysqli_query($koneksi, $querySelectGambar);

                if ($resultSelectGambar) {
                    $gambarToDelete = mysqli_fetch_assoc($resultSelectGambar)['gambar'];

                    if (!empty($gambarToDelete)) {
                        $gambarPath = 'images/' . $gambarToDelete;
                        if (file_exists($gambarPath)) {
                            unlink($gambarPath); // Hapus gambar dari direktori
                            error_log("Gambar dihapus: $gambarPath");
                        } else {
                            error_log("Gambar tidak ditemukan: $gambarPath");
                        }
                    }
                } else {
                    error_log("Error fetching gambar: " . mysqli_error($koneksi));
                }

                // Hapus menu dari database
                $query = "DELETE FROM menu WHERE id = $id";
                if (mysqli_query($koneksi, $query)) {
                    echo json_encode(["message" => "Menu deleted successfully!", "id" => $id]);

                    // Perbarui urutan id_makanan di tabel makanan
                    $query_update = "ALTER TABLE menu AUTO_INCREMENT=1";
                    if (!mysqli_query($koneksi, $query_update)) {
                        error_log("Error resetting AUTO_INCREMENT: " . mysqli_error($koneksi));
                    }
                    $query_update = "SET @count = 0";
                    if (!mysqli_query($koneksi, $query_update)) {
                        error_log("Error setting count: " . mysqli_error($koneksi));
                    }
                    $query_update = "UPDATE menu SET id = @count:= @count + 1";
                    if (!mysqli_query($koneksi, $query_update)) {
                        error_log("Error updating ids: " . mysqli_error($koneksi));
                    }
                } else {
                    echo json_encode(["error" => "Error deleting menu: " . mysqli_error($koneksi)]);
                    error_log("Error deleting menu: " . mysqli_error($koneksi));
                }
            } else {
                echo json_encode(["error" => "No id provided"]);
                error_log("No id provided for deletion");
            }
        } elseif (isset($_POST['action']) && $_POST['action'] === 'update') {
            $id = $_POST['id'];
            $id_penjual = (int)$_POST['id_penjual'];
            $nama = $_POST['nama'];
            $deskripsi = $_POST['deskripsi'];
            $harga = $_POST['harga'];
            $stok = $_POST['stok'];

            // Proses penyimpanan gambar
            if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == UPLOAD_ERR_OK) {
                // Dapatkan gambar lama
                $querySelectGambar = "SELECT gambar FROM menu WHERE id = $id";
                $resultSelectGambar = mysqli_query($koneksi, $querySelectGambar);

                if ($resultSelectGambar) {
                    $gambarToDelete = mysqli_fetch_assoc($resultSelectGambar)['gambar'];

                    // Hapus gambar lama jika ada
                    if (!empty($gambarToDelete)) {
                        $gambarPath = 'images/' . $gambarToDelete;
                        if (file_exists($gambarPath)) {
                            unlink($gambarPath); // Hapus gambar dari direktori
                            error_log("Gambar lama dihapus: $gambarPath");
                        } else {
                            error_log("Gambar lama tidak ditemukan: $gambarPath");
                        }
                    }
                } else {
                    error_log("Error fetching gambar lama: " . mysqli_error($koneksi));
                }

                // Upload gambar baru
                $gambar = $_FILES['gambar']['name'];
                $tempName = $_FILES['gambar']['tmp_name'];
                $gambarDestination = 'images/' . $gambar;
                move_uploaded_file($tempName, $gambarDestination);

                // Query untuk mengupdate data menu termasuk gambar baru
                $query = "UPDATE menu SET id_penjual = '$id_penjual', nama = '$nama', deskripsi = '$deskripsi', harga = '$harga', stok = '$stok', gambar = '$gambar' WHERE id = '$id'";
            } else {
                // Query untuk mengupdate data menu tanpa mengubah gambar
                $query = "UPDATE menu SET id_penjual = '$id_penjual', nama = '$nama', deskripsi = '$deskripsi', harga = '$harga', stok = '$stok' WHERE id = '$id'";
            }

            if (mysqli_query($koneksi, $query)) {
                $result = mysqli_query($koneksi, "SELECT * FROM menu WHERE id = $id");
                $menuData = mysqli_fetch_assoc($result);
                echo json_encode(["message" => "Menu updated successfully!", "menu" => $menuData]);
            } else {
                echo json_encode(["message" => "Error updating menu: " . mysqli_error($koneksi)]);
            }
        } else {
            $id_penjual = $_POST['id_penjual'];
            $nama = $_POST['nama'];
            $deskripsi = $_POST['deskripsi'];
            $harga = $_POST['harga'];
            $stok = $_POST['stok'];

            // Handle file upload
            if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == UPLOAD_ERR_OK) {
                $target_dir = "images/";
                $target_file = $target_dir . basename($_FILES["gambar"]["name"]);

                if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
                    $gambar = basename($_FILES["gambar"]["name"]);

                    $query = "INSERT INTO menu (id_penjual, nama, deskripsi, harga, stok, gambar) VALUES ('$id_penjual', '$nama', '$deskripsi', '$harga', '$stok', '$gambar')";

                    if (mysqli_query($koneksi, $query)) {
                        $menuId = mysqli_insert_id($koneksi);
                        $result = mysqli_query($koneksi, "SELECT * FROM menu WHERE id = $menuId");
                        $menuData = mysqli_fetch_assoc($result);

                        echo json_encode(["message" => "Menu added successfully!", "menu" => $menuData]);
                    } else {
                        echo json_encode(["message" => "Error adding menu: " . mysqli_error($koneksi)]);
                    }

                    // Perbarui urutan id_makanan di tabel makanan
                    $query_update = "ALTER TABLE menu AUTO_INCREMENT=1";
                    mysqli_query($koneksi, $query_update);
                    $query_update = "SET @count = 0";
                    mysqli_query($koneksi, $query_update);
                    $query_update = "UPDATE menu SET id = @count:= @count + 1";
                    mysqli_query($koneksi, $query_update);
                } else {
                    echo json_encode(["error" => "Error uploading image"]);
                }
            } else {
                echo json_encode(["error" => "No image uploaded or upload error"]);
            }
        }
        break;

    default:
        echo json_encode(["message" => "Invalid request method"]);
        error_log("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
        break;
}

mysqli_close($koneksi);
