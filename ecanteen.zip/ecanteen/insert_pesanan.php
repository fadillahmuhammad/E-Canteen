<?php
header('Content-Type: application/json');

// Koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(array("status" => "error", "message" => "Gagal koneksi ke database: " . mysqli_connect_error()));
    exit();
}

if (isset($_POST['id_pembeli'])) {
    $idPembeli = $_POST['id_pembeli'];
    $idPenjual = $_POST['id_penjual'];
    $idMenu = $_POST['id_menu'];
    $noPesanan = $_POST['no_pesanan'];
    $qty = $_POST['qty'];
    $catatan = $_POST['catatan'];
    $jamPesan = $_POST['jam_pesan'];
    $jmlHarga = $_POST['jml_harga'];
    $status = $_POST['status'];
    $tipeUserPembeli = "pembeli";
    $tipeUserPenjual = "penjual";

    // Mulai transaksi
    mysqli_begin_transaction($koneksi);

    try {
        $query_update = "ALTER TABLE pesanan AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE pesanan SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);

        $query_insert_pesanan = "INSERT INTO pesanan (no_pesanan, id_menu, id_pembeli, qty, catatan, jam_pesan, jml_harga, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $insert_pesanan_stmt = mysqli_prepare($koneksi, $query_insert_pesanan);
        mysqli_stmt_bind_param($insert_pesanan_stmt, "siiissii", $noPesanan, $idMenu, $idPembeli, $qty, $catatan, $jamPesan, $jmlHarga, $status);
        $insert_pesanan_result = mysqli_stmt_execute($insert_pesanan_stmt);

        if (!$insert_pesanan_result) {
            throw new Exception("Gagal menyimpan riwayat pesanan.");
        }

        $query_update = "ALTER TABLE saldo AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE saldo SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);

        $query_update_saldo_penjual = "UPDATE saldo SET jumlah_saldo = jumlah_saldo + ? WHERE id_user = ? AND tipe_user = ?";
        $update_saldo_penjual_stmt = mysqli_prepare($koneksi, $query_update_saldo_penjual);
        mysqli_stmt_bind_param($update_saldo_penjual_stmt, "iis", $jmlHarga, $idPenjual, $tipeUserPenjual);
        $update_saldo_penjual_result = mysqli_stmt_execute($update_saldo_penjual_stmt);

        if (!$update_saldo_penjual_result) {
            throw new Exception("Gagal memperbarui saldo penjual.");
        }

        $query_update = "ALTER TABLE saldo AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE saldo SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);

        $query_update_saldo_pembeli = "UPDATE saldo SET jumlah_saldo = jumlah_saldo - ? WHERE id_user = ? AND tipe_user = ?";
        $update_saldo_pembeli_stmt = mysqli_prepare($koneksi, $query_update_saldo_pembeli);
        mysqli_stmt_bind_param($update_saldo_pembeli_stmt, "iis", $jmlHarga, $idPembeli, $tipeUserPembeli);
        $update_saldo_pembeli_result = mysqli_stmt_execute($update_saldo_pembeli_stmt);

        if (!$update_saldo_pembeli_result) {
            throw new Exception("Gagal memperbarui saldo pembeli.");
        }

        $query_update = "ALTER TABLE transaksi_saldo AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE transaksi_saldo SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);

        $query_insert_transaksi_saldo_beli_menu = "INSERT INTO transaksi_saldo (id_user, tipe_user, jenis_transaksi, jumlah_transaksi, id_menu) VALUES (?, ?, 'beli_menu', ?, ?)";
        $insert_transaksi_saldo_beli_menu_stmt = mysqli_prepare($koneksi, $query_insert_transaksi_saldo_beli_menu);
        mysqli_stmt_bind_param($insert_transaksi_saldo_beli_menu_stmt, "isii", $idPembeli, $tipeUserPembeli, $jmlHarga, $idMenu);
        $insert_transaksi_saldo_beli_menu_result = mysqli_stmt_execute($insert_transaksi_saldo_beli_menu_stmt);

        if (!$insert_transaksi_saldo_beli_menu_result) {
            throw new Exception("Gagal menyimpan transaksi saldo pembelian.");
        }

        $query_update = "ALTER TABLE transaksi_saldo AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE transaksi_saldo SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);

        $query_insert_transaksi_saldo_pemasukan = "INSERT INTO transaksi_saldo (id_user, tipe_user, jenis_transaksi, jumlah_transaksi, id_menu) VALUES (?, ?, 'pemasukan', ?, ?)";
        $insert_transaksi_saldo_pemasukan_stmt = mysqli_prepare($koneksi, $query_insert_transaksi_saldo_pemasukan);
        mysqli_stmt_bind_param($insert_transaksi_saldo_pemasukan_stmt, "isii", $idPenjual, $tipeUserPenjual, $jmlHarga, $idMenu);
        $insert_transaksi_saldo_pemasukan_result = mysqli_stmt_execute($insert_transaksi_saldo_pemasukan_stmt);

        if (!$insert_transaksi_saldo_pemasukan_result) {
            throw new Exception("Gagal menyimpan transaksi saldo pemasukan.");
        }

        $query_update = "ALTER TABLE history AUTO_INCREMENT=1";
        mysqli_query($koneksi, $query_update);
        $query_update = "SET @count = 0";
        mysqli_query($koneksi, $query_update);
        $query_update = "UPDATE history SET id = @count:= @count + 1";
        mysqli_query($koneksi, $query_update);
        
        $query_insert_history = "INSERT INTO history (no_pesanan, id_menu, id_pembeli, qty, catatan, jam_pesan, jml_harga) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $insert_history_stmt = mysqli_prepare($koneksi, $query_insert_history);
        mysqli_stmt_bind_param($insert_history_stmt, "siiissi", $noPesanan, $idMenu, $idPembeli, $qty, $catatan, $jamPesan, $jmlHarga);
        $insert_history_result = mysqli_stmt_execute($insert_history_stmt);

        if (!$insert_history_result) {
            throw new Exception("Gagal menyimpan history.");
        }

        // Komit transaksi
        mysqli_commit($koneksi);

        echo json_encode(array("status" => "success", "message" => "Pesanan berhasil ditambahkan."));
    } catch (Exception $e) {
        // Rollback transaksi jika terjadi kesalahan
        mysqli_rollback($koneksi);
        echo json_encode(array("status" => "error", "message" => $e->getMessage()));
    } finally {
        // Menutup statement dan koneksi
        mysqli_stmt_close($insert_pesanan_stmt);
        mysqli_stmt_close($update_saldo_penjual_stmt);
        mysqli_stmt_close($update_saldo_pembeli_stmt);
        mysqli_stmt_close($insert_transaksi_saldo_beli_menu_stmt);
        mysqli_stmt_close($insert_transaksi_saldo_pemasukan_stmt);
        mysqli_stmt_close($insert_history_stmt);
        mysqli_close($koneksi);
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Data tidak lengkap."));
}