<?php
header('Content-Type: application/json');

// Koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(array("status" => "error", "message" => "Gagal koneksi ke database: " . mysqli_connect_error()));
    exit();
}

if (isset($_POST['id_pembeli'])) {
    $id = $_POST['id_pembeli'];

    $query_new = "SELECT 
                    pes.id,
                    pes.no_pesanan, 
                    pes.id_menu,
                    pes.id_pembeli, 
                    pes.qty, 
                    pes.catatan, 
                    pes.jam_pesan, 
                    pes.jml_harga,
                    pes.tanggal,
                    pes.status,
                    m.id_penjual,
                    m.nama,
                    m.deskripsi,
                    m.harga,
                    m.stok,
                    m.gambar,
                    pen.nama_toko,
                    pen.nama_lengkap,
                    pen.telp
                FROM pesanan pes
                LEFT JOIN menu m ON pes.id_menu = m.id 
                LEFT JOIN penjual pen ON m.id_penjual = pen.id 
                WHERE pes.id_pembeli = $id";

    $result = mysqli_query($koneksi, $query_new);

    if ($result) {
        $data = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
        echo json_encode(array("status" => "success", "data_pesanan_pembeli" => $data));
    } else {
        echo json_encode(array("status" => "error", "message" => "Query gagal: " . mysqli_error($koneksi)));
    }
} else if (isset($_POST['id_pesanan_pembeli'])) {
    $id = $_POST['id_pesanan_pembeli'];

    $query_new = "SELECT 
                    pes.id,
                    pes.no_pesanan, 
                    pes.id_menu,
                    pes.id_pembeli, 
                    pes.qty, 
                    pes.catatan, 
                    pes.jam_pesan, 
                    pes.jml_harga,
                    pes.tanggal,
                    pes.status,
                    m.id_penjual,
                    m.nama,
                    m.deskripsi,
                    m.harga,
                    m.stok,
                    m.gambar,
                    pen.nama_toko,
                    pen.nama_lengkap,
                    pen.telp
                FROM pesanan pes
                LEFT JOIN menu m ON pes.id_menu = m.id 
                LEFT JOIN penjual pen ON m.id_penjual = pen.id 
                WHERE pes.id = $id";

    $result = mysqli_query($koneksi, $query_new);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        echo json_encode(array("status" => "success", "data_detail_pesanan_pembeli" => $row));
    } else {
        echo json_encode(array("status" => "error", "message" => "Query gagal: " . mysqli_error($koneksi)));
    }
} elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {

    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        $query = "DELETE FROM pesanan WHERE id = $id";
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(["message" => "Pesanan deleted successfully!", "id" => $id]);

            // Perbarui urutan id_makanan di tabel makanan
            $query_update = "ALTER TABLE pesanan AUTO_INCREMENT=1";
            if (!mysqli_query($koneksi, $query_update)) {
                error_log("Error resetting AUTO_INCREMENT: " . mysqli_error($koneksi));
            }
            $query_update = "SET @count = 0";
            if (!mysqli_query($koneksi, $query_update)) {
                error_log("Error setting count: " . mysqli_error($koneksi));
            }
            $query_update = "UPDATE pesanan SET id = @count:= @count + 1";
            if (!mysqli_query($koneksi, $query_update)) {
                error_log("Error updating ids: " . mysqli_error($koneksi));
            }
        } else {
            echo json_encode(["error" => "Error deleting menu: " . mysqli_error($koneksi)]);
            error_log("Error deleting menu: " . mysqli_error($koneksi));
        }
    } else {
        echo json_encode(["error" => "No id provided"]);
        error_log("No id provided for deletion");
    }
}

mysqli_close($koneksi);
