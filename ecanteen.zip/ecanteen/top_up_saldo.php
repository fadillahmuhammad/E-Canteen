<?php
header('Content-Type: application/json');

// Koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(array("status" => "error", "message" => "Gagal koneksi ke database: " . mysqli_connect_error()));
    exit();
}

if (isset($_POST['id_user']) && isset($_POST['tipe_user']) && isset($_POST['id_saldo']) && isset($_POST['amount'])) {
    $id_user = intval($_POST['id_user']);
    $tipe_user = $_POST['tipe_user'];
    $id_saldo = intval($_POST['id_saldo']);
    $amount = intval($_POST['amount']);

    if ($id_user == 0 || ($tipe_user != 'pembeli' && $tipe_user != 'penjual')) {
        echo json_encode(array("status" => "error", "message" => "Parameter tidak valid."));
        exit();
    }

    // Ambil jumlah saldo saat ini
    $select_query = "SELECT jumlah_saldo FROM saldo WHERE id = ?";
    $stmt = mysqli_prepare($koneksi, $select_query);
    mysqli_stmt_bind_param($stmt, "i", $id_saldo);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $data = mysqli_fetch_assoc($result);
        if ($data) {
            $currentAmount = intval($data['jumlah_saldo']);
            $newAmount = $currentAmount + $amount;

            // Update jumlah saldo dengan nilai baru
            $update_query = "UPDATE saldo SET jumlah_saldo = ? WHERE id = ?";
            $update_stmt = mysqli_prepare($koneksi, $update_query);
            mysqli_stmt_bind_param($update_stmt, "ii", $newAmount, $id_saldo);
            $update_result = mysqli_stmt_execute($update_stmt);

            if ($update_result) {
                $query_update = "ALTER TABLE transaksi_saldo AUTO_INCREMENT=1";
                mysqli_query($koneksi, $query_update);
                $query_update = "SET @count = 0";
                mysqli_query($koneksi, $query_update);
                $query_update = "UPDATE transaksi_saldo SET id = @count:= @count + 1";
                mysqli_query($koneksi, $query_update);

                // Insert transaksi top-up ke dalam tabel transaksi_saldo
                $insert_history_query = "INSERT INTO transaksi_saldo (id_user, tipe_user, jenis_transaksi, jumlah_transaksi) VALUES (?, ?, 'topup', ?)";
                $insert_stmt = mysqli_prepare($koneksi, $insert_history_query);
                mysqli_stmt_bind_param($insert_stmt, "isi", $id_user, $tipe_user, $amount);
                $insert_result = mysqli_stmt_execute($insert_stmt);

                if ($insert_result) {
                    echo json_encode(array("status" => "success", "message" => "Saldo berhasil ditambahkan."));
                } else {
                    echo json_encode(array("status" => "error", "message" => "Gagal menyimpan riwayat transaksi."));
                }
            } else {
                echo json_encode(array("status" => "error", "message" => "Gagal memperbarui saldo."));
            }
        } else {
            echo json_encode(array("status" => "error", "message" => "Data saldo tidak ditemukan."));
        }
    } else {
        echo json_encode(array("status" => "error", "message" => "Query gagal dijalankan."));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Parameter tidak valid."));
}

mysqli_close($koneksi);
