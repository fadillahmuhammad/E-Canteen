<?php
header('Content-Type: application/json');

// koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(["error" => "Gagal koneksi ke database: " . mysqli_connect_error()]);
    exit();
}

$query_update = "ALTER TABLE penjual AUTO_INCREMENT=1";
mysqli_query($koneksi, $query_update);
$query_update = "SET @count = 0";
mysqli_query($koneksi, $query_update);
$query_update = "UPDATE penjual SET id = @count:= @count + 1";
mysqli_query($koneksi, $query_update);

if (isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = $_POST['id'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $telp = $_POST['telp'];
    $nama_toko = $_POST['nama_toko'];
    $deskripsi = $_POST['deskripsi'];

    $query = "UPDATE penjual SET nama_lengkap = '$nama_lengkap', telp = '$telp', nama_toko = '$nama_toko', deskripsi = '$deskripsi' WHERE id = '$id'";

    if (mysqli_query($koneksi, $query)) {
        $tipe_user = "penjual";
        $update_saldo = mysqli_query($koneksi, "UPDATE saldo SET nama_pemilik = '$nama_lengkap' WHERE id_user = '$id' AND tipe_user = '$tipe_user'");

        $result = mysqli_query($koneksi, "SELECT * FROM penjual WHERE id = $id");
        $profileData = mysqli_fetch_assoc($result);
        echo json_encode(["message" => "profile updated successfully!", "profile" => $profileData]);
    } else {
        echo json_encode(["message" => "Error updating profile: " . mysqli_error($koneksi)]);
    }
}

mysqli_close($koneksi);
