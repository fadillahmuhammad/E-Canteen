<?php
header('Content-Type: application/json');
//koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo "Gagal koneksi ke database: " . mysqli_connect_errno();
}

$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM pembeli WHERE username = '$username' AND password = '$password'";
$obj_query = mysqli_query($koneksi, $query);
$data = mysqli_fetch_array($obj_query);

if ($data) {
    $token = uniqid();

    $update_query = "UPDATE pembeli SET token = '$token' WHERE username = '$username'";
    mysqli_query($koneksi, $update_query);

    echo json_encode(
        array(
            'message' => 'Berhasil login!',
            'token' => $token,
            'payload' => array(
                "id" => $data['id'],
                "nama_lengkap" => $data['nama_lengkap'],
                "telp" => $data['telp'],
                "username" => $data['username'],
            )
        )
    );
} else {
    echo json_encode(
        array(
            'message' => 'Username atau password salah!',
            'payload' => null
        )
    );
}
