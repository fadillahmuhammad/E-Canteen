<?php
header('Content-Type: application/json');
//koneksi ke database
$server = "localhost";
$username = "id22207523_fadillah";
$password = "@Nisfuramadhani111200";
$database = "id22207523_ecanteen";
$koneksi = mysqli_connect($server, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo json_encode(array("status" => "error", "message" => "Gagal koneksi ke database: " . mysqli_connect_error()));
    exit();
}

// Mendapatkan data dari URL
$id_user = isset($_POST['id_user']) ? intval($_POST['id_user']) : 0;
$tipe_user = isset($_POST['tipe_user']) ? $_POST['tipe_user'] : '';

if ($id_user == 0 || ($tipe_user != 'pembeli' && $tipe_user != 'penjual')) {
    echo json_encode(array("status" => "error", "message" => "Parameter tidak valid."));
    exit();
}

// Query untuk mendapatkan data transaksi saldo dan informasi menu
$query = "SELECT ts.jenis_transaksi, ts.jumlah_transaksi, ts.id_menu, ts.tanggal_transaksi, m.id_penjual, m.nama, m.gambar 
          FROM transaksi_saldo ts 
          LEFT JOIN menu m ON ts.id_menu = m.id 
          WHERE ts.id_user = ? AND ts.tipe_user = ?";

$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "is", $id_user, $tipe_user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $data = mysqli_fetch_all($result, MYSQLI_ASSOC);
    if ($data) {
        echo json_encode(array("status" => "success", "data" => $data));
    } else {
        echo json_encode(array("status" => "error", "message" => "Data tidak ditemukan."));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Query gagal dijalankan."));
}

mysqli_close($koneksi);
